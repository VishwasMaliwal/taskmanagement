// src/app/models/board.ts
export interface Board {
    id: number;
    name: string;
    columns: Column[];
  }
  
  // src/app/models/column.ts
  export interface Column {
    id: number;
    name: string;
    tasks: Task[];
  }
  
  // src/app/models/task.ts
  export interface Task {
    id: number;
    title: string;
    description: string;
  }
  