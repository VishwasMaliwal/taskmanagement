// src/main/java/com/example/kanban/model/Task.java
package com.example.kanban.model;

import javax.persistence.*;

@Entity
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToOne
    @JoinColumn(name = "column_id")
    private Column column;

    // getters and setters
}
