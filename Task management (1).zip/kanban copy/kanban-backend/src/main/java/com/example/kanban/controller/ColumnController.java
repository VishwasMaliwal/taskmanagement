// src/main/java/com/example/kanban/controller/ColumnController.java
package com.example.kanban.controller;

import com.example.kanban.model.Column;
import com.example.kanban.repository.ColumnRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/columns")
public class ColumnController {

    @Autowired
    private ColumnRepository columnRepository;

    @GetMapping
    public List<Column> getAllColumns() {
        return columnRepository.findAll();
    }

    @PostMapping
    public Column createColumn(@RequestBody Column column) {
        return columnRepository.save(column);
    }

    // Add more endpoints as needed
}
