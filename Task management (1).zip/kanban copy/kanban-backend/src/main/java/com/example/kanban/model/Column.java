// src/main/java/com/example/kanban/model/Column.java
package com.example.kanban.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Column {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToOne
    @JoinColumn(name = "board_id")
    private Board board;

    @OneToMany(mappedBy = "column", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Task> tasks;

    // getters and setters
}
