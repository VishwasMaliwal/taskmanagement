// src/main/java/com/example/kanban/repository/BoardRepository.java
package com.example.kanban.repository;

import com.example.kanban.model.Board;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface BoardRepository extends JpaRepository<Board, Long> {
}
