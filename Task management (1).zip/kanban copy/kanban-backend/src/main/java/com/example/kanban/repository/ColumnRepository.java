// src/main/java/com/example/kanban/repository/ColumnRepository.java
package com.example.kanban.repository;

import com.example.kanban.model.Column;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColumnRepository extends JpaRepository<Column, Long> {
}
