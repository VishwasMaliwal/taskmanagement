-- src/main/resources/data.sql

INSERT INTO board (name) VALUES ('Project A');
INSERT INTO board (name) VALUES ('Project B');

INSERT INTO column (name, board_id) VALUES ('To Do', 1);
INSERT INTO column (name, board_id) VALUES ('In Progress', 1);
INSERT INTO column (name, board_id) VALUES ('Done', 1);

INSERT INTO task (title, description, column_id) VALUES ('Task 1', 'Description for Task 1', 1);
INSERT INTO task (title, description, column_id) VALUES ('Task 2', 'Description for Task 2', 2);
INSERT INTO task (title, description, column_id) VALUES ('Task 3', 'Description for Task 3', 3);
